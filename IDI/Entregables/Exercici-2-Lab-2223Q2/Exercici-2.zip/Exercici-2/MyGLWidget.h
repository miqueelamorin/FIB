#include "LL2GLWidget.h"

#include "model.h"

class MyGLWidget : public LL2GLWidget {
  Q_OBJECT

  public:
    MyGLWidget(QWidget *parent=0) : LL2GLWidget(parent) {}
    ~MyGLWidget();

  protected:

  private:

    int printOglError(const char file[], int line, const char func[]);

    virtual void RickTransform();
    virtual void MortyTransform();
    virtual void VideoCameraTransform();

    virtual void iniCamera ();
    virtual void iniEscena ();
    virtual void viewTransform();

    virtual void mouseMoveEvent (QMouseEvent *event);

    virtual void keyPressEvent (QKeyEvent *event);

    float anglecamera;
    float anglemorty;
};
