// MyGLWidget.cpp
#include "MyGLWidget.h"
#include <iostream>
#include <stdio.h>

#define printOpenGLError() printOglError(__FILE__, __LINE__)
#define CHECK() printOglError(__FILE__, __LINE__,__FUNCTION__)
#define DEBUG() std::cout << __FILE__ << " " << __LINE__ << " " << __FUNCTION__ << std::endl;

int MyGLWidget::printOglError(const char file[], int line, const char func[]) 
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    const char * error = 0;
    switch (glErr)
    {
        case 0x0500:
            error = "GL_INVALID_ENUM";
            break;
        case 0x501:
            error = "GL_INVALID_VALUE";
            break;
        case 0x502: 
            error = "GL_INVALID_OPERATION";
            break;
        case 0x503:
            error = "GL_STACK_OVERFLOW";
            break;
        case 0x504:
            error = "GL_STACK_UNDERFLOW";
            break;
        case 0x505:
            error = "GL_OUT_OF_MEMORY";
            break;
        default:
            error = "unknown error!";
    }
    if (glErr != GL_NO_ERROR)
    {
        printf("glError in file %s @ line %d: %s function: %s\n",
                             file, line, error, func);
        retCode = 1;
    }
    return retCode;
}

MyGLWidget::~MyGLWidget() {
}

void MyGLWidget::iniEscena ()
{
  creaBuffersPatricio();
  creaBuffersAvio();
  creaBuffersHangar();
  creaBuffersTerra();

  // Paràmetres de l'escena - arbitraris
  centreEsc = glm::vec3 (15, 1.25, 12);
  radiEsc = sqrt(15*15+1.25*1.25+12*12);
  angleavio = 0;
  alcadaavio = 0;
  emit setalcada(alcadaavio);
}

void MyGLWidget::iniMaterialTerra()
{
  amb = glm::vec3(0.2,0.1,0.2);
  diff = glm::vec3(0,1,1);
  spec = glm::vec3(1,1,1);
  shin = 500;
}

void MyGLWidget::enviaPosFocus()
{
  if (focuscamera) posFoc = glm::vec3(0,0,0);
  else posFoc = View * TGAvio * glm::vec4(0,0,0,1.f);
  glUniform3fv (posfocusLoc, 1, &posFoc[0]);
}

void MyGLWidget::iniCamera ()
{
  angleY = 0.5;
  angleX = -0.5;
  camera2 = false;
  ra = float(width())/height();
  fov = 2*asin(radiEsc/(2.0*radiEsc));
  zn = radiEsc;
  zf = 3*radiEsc;
  focuscamera = true;
  emit setcam1(not camera2);
  emit setcam2(camera2);

  projectTransform ();
  viewTransform ();
}

void MyGLWidget::paintGL ()
{
  ExamGLWidget::paintGL();
}

void MyGLWidget::modelTransformPatricio ()
{
  glm::mat4 TG(1.f);
  TG = glm::translate(TG, glm::vec3 (15, 0, 12));
  TG = glm::rotate(TG, -float(M_PI/2), glm::vec3(0,1,0));
  TG = glm::scale(TG, glm::vec3 (2*escalaPat, 2*escalaPat, 2*escalaPat));
  TG = glm::translate(TG, -centreBasePat);

  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
}

void MyGLWidget::modelTransformAvio ()
{
  TGAvio = glm::mat4(1.f);
  TGAvio = glm::translate(TGAvio, glm::vec3 (15, alcadaavio, 12));
  TGAvio = glm::rotate(TGAvio, -angleavio, glm::vec3(0,1,0));
  TGAvio = glm::translate(TGAvio, glm::vec3(10,0,0));
  TGAvio = glm::scale(TGAvio, glm::vec3 (1.5*escalaAvio, 1.5*escalaAvio, 1.5*escalaAvio));
  TGAvio = glm::translate(TGAvio, -centreBaseAvio);

  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TGAvio[0][0]);
}

void MyGLWidget::viewTransform ()
{
  if (!camera2){
    View = glm::translate(glm::mat4(1.f), glm::vec3(0, 0, -2*radiEsc));
    View = glm::rotate(View, -angleX, glm::vec3(1, 0, 0));
    View = glm::rotate(View, angleY, glm::vec3(0, 1, 0));
    View = glm::translate(View, -centreEsc);
  }
  else
  {
    View = glm::translate(glm::mat4(1.f), glm::vec3(0, -1.25, 0));
    View = glm::rotate(View, -float(M_PI/2), glm::vec3(0, 1, 0));
    View = glm::translate(View, -centreEsc);
    //View = glm::lookAt(glm::vec3(15,3,12),glm::vec3(5,3,12),glm::vec3(0,1,0));
  }
  glUniformMatrix4fv (viewLoc, 1, GL_FALSE, &View[0][0]);
}

void MyGLWidget::projectTransform ()
{
  glm::mat4 Proj;  // Matriu de projecció
  if (!camera2){
    Proj = glm::perspective(fov, ra, zn, zf);
  }
  else
  {
    Proj = glm::perspective(float(M_PI/2), ra, 1.f, 15.f);
  }
  glUniformMatrix4fv (projLoc, 1, GL_FALSE, &Proj[0][0]);
}

void MyGLWidget::keyPressEvent(QKeyEvent* event) 
{
  makeCurrent();
  switch (event->key()) {
  case Qt::Key_Up: {
      if (alcadaavio < 5) ++alcadaavio;
      emit setalcada(alcadaavio);
    break;
	}
  case Qt::Key_Down: {
      if (alcadaavio > 0) --alcadaavio;
      emit setalcada(alcadaavio);
    break;
	}
  case Qt::Key_Right: {
      angleavio += float(M_PI/16);
    break;
	}
  case Qt::Key_F: {
      focuscamera = not focuscamera;
      enviaPosFocus();
    break;
	}
  case Qt::Key_C: {
      camera2 = not camera2;
      emit setcam1(not camera2);
      emit setcam2(camera2);
      viewTransform();
      projectTransform();
    break;
	}
  case Qt::Key_R: {
      iniEscena();
      iniCamera();
    break;
	}
  default: ExamGLWidget::keyPressEvent(event); break;
  }
  update();
}


void MyGLWidget::mouseMoveEvent(QMouseEvent *e)
{
  makeCurrent();
  if ((DoingInteractive == ROTATE) && !camera2)
  {
    // Fem la rotació
    angleY += (e->x() - xClick) * M_PI / ample;
    angleX -= (e->y() - yClick) * M_PI / alt;
    viewTransform ();
  }

  xClick = e->x();
  yClick = e->y();

  update ();
}

void MyGLWidget::botocamera1(){
  makeCurrent();
  camera2 = false;
  viewTransform();
  projectTransform();
  update();
}

void MyGLWidget::botocamera2(){
  makeCurrent();
  camera2 = true;
  viewTransform();
  projectTransform();
  update();
}

void MyGLWidget::botoalcada(int n){
  makeCurrent();
  alcadaavio = n;
  update();
}
