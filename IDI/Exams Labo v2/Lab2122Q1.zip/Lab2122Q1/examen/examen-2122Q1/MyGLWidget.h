#include "ExamGLWidget.h"

class MyGLWidget:public ExamGLWidget
{
  Q_OBJECT

  public:
    MyGLWidget(QWidget *parent=0) : ExamGLWidget(parent) {}
    ~MyGLWidget();

  protected:
    virtual void paintGL ();
    virtual void keyPressEvent(QKeyEvent* event);
    virtual void mouseMoveEvent (QMouseEvent *event);

    virtual void modelTransformPatricio ();
    virtual void modelTransformAvio ();
    virtual void iniEscena ();
    virtual void iniCamera ();
    virtual void projectTransform ();
    virtual void viewTransform ();
    virtual void enviaPosFocus ();
    virtual void iniMaterialTerra ();

    bool focuscamera;
    float angleavio;
    int alcadaavio;

  private:
    int printOglError(const char file[], int line, const char func[]);

  public slots:
    void botocamera1();
    void botocamera2();
    void botoalcada(int n);

  signals:
    void setcam1(bool b);
    void setcam2(bool b);
    void setalcada(int n);
};
