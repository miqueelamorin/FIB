#include "ExamGLWidget.h"

class MyGLWidget:public ExamGLWidget
{
  Q_OBJECT

  public:
    MyGLWidget(QWidget *parent=0) : ExamGLWidget(parent) {}
    ~MyGLWidget();

  protected:
    virtual void paintGL ();
    virtual void keyPressEvent(QKeyEvent* event);
    virtual void modelTransformCub (float escala, float angle);
    virtual void modelTransformPatricio ();
    virtual void projectTransform ();
    virtual void viewTransform ();
    
    void initializeGL ( );
    void enviaColFocus();
    
    void iniEscena ();
    bool pintapatricio;
    bool focusblanc;
    float left, right, bottom, top;
    
    float anglepatricio;
    float anglecub;
    
    public slots:
    void perspectiva();
    void ortogonal();
    void patricio_cub(int n);
    
    signals:
    void setPatricio(int n);
    void setPerspectiva();
    void setOrtogonal();

  private:
    int printOglError(const char file[], int line, const char func[]);
};
