// MyGLWidget.cpp
#include "MyGLWidget.h"
#include <iostream>
#include <stdio.h>

#define printOpenGLError() printOglError(__FILE__, __LINE__)
#define CHECK() printOglError(__FILE__, __LINE__,__FUNCTION__)
#define DEBUG() std::cout << __FILE__ << " " << __LINE__ << " " << __FUNCTION__ << std::endl;

int MyGLWidget::printOglError(const char file[], int line, const char func[]) 
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    const char * error = 0;
    switch (glErr)
    {
        case 0x0500:
            error = "GL_INVALID_ENUM";
            break;
        case 0x501:
            error = "GL_INVALID_VALUE";
            break;
        case 0x502: 
            error = "GL_INVALID_OPERATION";
            break;
        case 0x503:
            error = "GL_STACK_OVERFLOW";
            break;
        case 0x504:
            error = "GL_STACK_UNDERFLOW";
            break;
        case 0x505:
            error = "GL_OUT_OF_MEMORY";
            break;
        default:
            error = "unknown error!";
    }
    if (glErr != GL_NO_ERROR)
    {
        printf("glError in file %s @ line %d: %s function: %s\n",
                             file, line, error, func);
        retCode = 1;
    }
    return retCode;
}

MyGLWidget::~MyGLWidget() {
}

void MyGLWidget::paintGL ()   // Mètode que has de modificar
{
    if (colorfocusgroc) colFoc = glm::vec3(1,1,0);
    else colFoc = glm::vec3(1,1,1);
    ExamGLWidget::enviaColFocus();

     // Esborrem el frame-buffer i el depth-buffer
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Pintem el terra
    glBindVertexArray (VAO_Terra);
    modelTransformTerra ();
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    if (not pintacubs){
        // Pintem el Patricio
        glBindVertexArray (VAO_Patr);
        modelTransformPatricio ();
        glDrawArrays(GL_TRIANGLES, 0, patr.faces().size()*3);
    }

    else{
        // Pintem el cub
        glBindVertexArray(VAO_Cub);
        modelTransformCub (4.0, anglecub);
        glDrawArrays(GL_TRIANGLES, 0, 36);
        modelTransformCub (5.0, anglecub+2*M_PI/3);
        glDrawArrays(GL_TRIANGLES, 0, 36);
        modelTransformCub (6.0, anglecub+4*M_PI/3);
        glDrawArrays(GL_TRIANGLES, 0, 36);
    }

    glBindVertexArray(0);
}

void MyGLWidget::modelTransformCub (float escala, float angle) 
{
  //ExamGLWidget::modelTransformCub (1.0, 0.0);
  // En aquest mètode has de substituir aquest codi per construir la 
  // transformació geomètrica (TG) del cub usant els paràmetres adientment
    TG = glm::mat4(1.f);
    TG = rotate(TG, angle, glm::vec3(0,1,0));
    TG = translate(TG, glm::vec3(5, 0, 0));
    TG = scale(TG, glm::vec3(escala, escala, escala));
    glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
}

void MyGLWidget::modelTransformPatricio ()    // Mètode que has de modificar
{
  TG = glm::mat4(1.f);
  TG = rotate(TG, anglepatricio+anglecub, glm::vec3(0,1,0));
  TG = glm::translate(TG, glm::vec3(5, 0, 0));
  TG = rotate(TG, float(-M_PI/2), glm::vec3(0.0,1.0,0.0));
  TG = glm::scale(TG, glm::vec3 (2*escala, 2*escala, 2*escala));
  TG = glm::translate(TG, -centreBasePat);

  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
}

void MyGLWidget::viewTransform ()    // Mètode que has de modificar
{
  if (!camPlanta)
    ExamGLWidget::viewTransform();
  else
  {
    glm::mat4 View = glm::lookAt(glm::vec3(0,float(2*radiEsc),0),glm::vec3(0,0,0), glm::vec3(1,0,0));
    glUniformMatrix4fv (viewLoc, 1, GL_FALSE, &View[0][0]);
  }
}

void MyGLWidget::projectTransform ()
{
  if (!camPlanta)
    ExamGLWidget::projectTransform();
  else
  {
    ra = float(ample)/float(alt);

    if (ra >= 1){
        left = -radiEsc*ra;
        right = radiEsc*ra;
    }
    else{
        bottom = -radiEsc/ra;
        top = radiEsc/ra;
    }

    glm::mat4 Proj;  // Matriu de projecció
    Proj = glm::ortho(left, right, bottom, top, zn, zf);
    glUniformMatrix4fv (projLoc, 1, GL_FALSE, &Proj[0][0]);
  }
}

void MyGLWidget::keyPressEvent(QKeyEvent* event) {
  makeCurrent();
  switch (event->key()) {
  case Qt::Key_V: {
      pintacubs = not pintacubs;
    break;
	}
  case Qt::Key_1: {
      anglepatricio = 0.0;
      emit patriciocanviat(1);
    break;
	}
  case Qt::Key_2: {
      anglepatricio = 2*M_PI/3;
      emit patriciocanviat(2);
    break;
	}
  case Qt::Key_3: {
      anglepatricio = 4*M_PI/3;
      emit patriciocanviat(3);
    break;
	}
  case Qt::Key_F: {
      colorfocusgroc = not colorfocusgroc;
    break;
	}
  case Qt::Key_C: {
      camPlanta = not camPlanta;
      if (camPlanta) emit setOrtogonal();
      else emit setPerspectiva();
      viewTransform();
      projectTransform();
    break;
	}
  case Qt::Key_Right: {
      anglecub += 2*M_PI/3;
    break;
	}
  case Qt::Key_Left: {
      anglecub -= 2*M_PI/3;
    break;
	}
  case Qt::Key_R: {
      reset();
    break;
	}
  default: ExamGLWidget::keyPressEvent(event); break;
  }
  update();
}

void MyGLWidget::initializeGL (){
    // Cal inicialitzar l'ús de les funcions d'OpenGL
    initializeOpenGLFunctions();

    glClearColor(0.5, 0.7, 1.0, 1.0); // defineix color de fons (d'esborrat)
    glEnable(GL_DEPTH_TEST);
    carregaShaders();

    iniEscena ();
    iniCamera ();

    pintacubs = true;
    colorfocusgroc = false;
    anglepatricio = 0.0;
    anglecub = 0.0;

    left = -radiEsc*ra;
    right = radiEsc*ra;
    bottom = -radiEsc/ra;
    top = radiEsc/ra;
}

void MyGLWidget::reset(){
    pintacubs = true;
    colorfocusgroc = false;
    anglepatricio = 0.0;
    anglecub = 0.0;
    ExamGLWidget::iniCamera();
}

void MyGLWidget::perspectiva(){
    makeCurrent();
    camPlanta = false;
    viewTransform();
    projectTransform();
    update();
}

void MyGLWidget::ortogonal(){
    makeCurrent();
    camPlanta = true;
    viewTransform();
    projectTransform();
    update();
}

void MyGLWidget::mourepatricio(int n){
    makeCurrent();
    if (n == 1) anglepatricio = 0.0;
    else if (n == 2) anglepatricio = 2*M_PI/3;
    else anglepatricio = 4*M_PI/3;
    update();
}

